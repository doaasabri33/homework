
package newpackage;


public class R5 {
    
public static int sumPositiveIntegers(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}
    
}
