
package newpackage;

public class R4 {
 
public static boolean isEven(int i) {
    return (i & 1) == 0; 
}  
}
